package com.legato.scm.pojo;

public class Registration {

}
