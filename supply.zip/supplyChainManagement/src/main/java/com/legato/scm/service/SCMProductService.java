
package com.legato.scm.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.legato.scm.daoimp.SCMProductDaoimp;
import com.legato.scm.entity.ProductEntity;
import com.legato.scm.pojo.Product;
import com.legato.scm.pojo.Products;

@Service
public class SCMProductService {
	@Autowired
	SCMProductDaoimp scmproductdao;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Products getProductData() {
		List<ProductEntity> productList = scmproductdao.getProductData();
		List<com.legato.scm.pojo.Product> list = new ArrayList<>();
		com.legato.scm.pojo.Product pro = null;
		for (ProductEntity p : productList) {
			pro = new com.legato.scm.pojo.Product();
			pro.setPid(p.getPid());
			pro.setPname(p.getPname());
			pro.setAmount(p.getAmount());
			list.add(pro);
		}
		Collections.sort(list, new Comparator() {
			@Override
			public int compare(Object o1, Object o2) {
				com.legato.scm.pojo.Product p1 = (com.legato.scm.pojo.Product) o1;
				com.legato.scm.pojo.Product p2 = (com.legato.scm.pojo.Product) o2;
				return (int) (p1.getPid() - p2.getPid());
			}
		});
		Products products = new Products();
		products.setProducts(list);
		return products;
	}

	@Transactional
	public String saveProductData(Product product) {
		Product pro = new Product();
		pro.setPid(product.getPid());
		pro.setAmount(product.getAmount());
		String message = scmproductdao.saveProductData(product);
		return message;
	}

	@Transactional
	public String deleteProductData(String pid) {
		String message = scmproductdao.deleteProductData(Integer.parseInt(pid));
		return message;
	}

	@Transactional
	public String updateProductData(String pid, String amount, String pname) {
		String message = scmproductdao.updateProductData(Integer.parseInt(pid), amount, pname);
		return message;
	}
}
