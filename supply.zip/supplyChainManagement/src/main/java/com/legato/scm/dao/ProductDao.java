package com.legato.scm.dao;

import java.util.List;

import com.legato.scm.entity.ProductEntity;
import com.legato.scm.pojo.Product;

public interface ProductDao {

	public List<ProductEntity> getProductData();

	public String saveProductData(Product p);

	public String updateProductData(int pid, String amount, String pname);

	public String deleteProductData(int pid);

}