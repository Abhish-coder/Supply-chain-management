package com.legato.scm.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SCM_REGISTRATION")
//@NamedQueries({ @NamedQuery(name = "Product.view", query = "from ProductEntity"),
	//	@NamedQuery(name = "Product.delete", query = "delete from ProductEntity p where p.pid=:pid"),
	//	@NamedQuery(name = "Product.update", query = "update Product p set p.pname = :name, p.amount = :amount where p.pid=:pid") })

public class RegistrationEntity {

	@Id
	@SequenceGenerator(name = "RegistrationEntity", sequenceName = "SCM_USERENTITY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RegistrationEntity")
	@Column(name = "email")
	private String email;

	@Column(name = "fname")
	private String fname;

	@Column(name = "lname")
	private String lname;

	@Column(name = "role")
	private String role;

	@Column(name = "")
	private Date createdAt;

	@Column(name = "quantityAvailable")
	private int quantityAvailable;

	@Column(name = "design")
	private String design;

	
}
