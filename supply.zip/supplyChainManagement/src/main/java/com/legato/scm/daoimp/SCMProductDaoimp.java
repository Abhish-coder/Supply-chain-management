package com.legato.scm.daoimp;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.legato.scm.entity.ProductEntity;
import com.legato.scm.pojo.Product;

@Repository
public class SCMProductDaoimp {

	@Autowired
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@SuppressWarnings("unchecked")
	public List<ProductEntity> getProductData() {
		Session session = sessionFactory.getCurrentSession();
		return session.getNamedQuery("Product.view").list();
	}

	public String saveProductData(Product p) {
		Session session = sessionFactory.getCurrentSession();
		session.save(p);
		return "success";
	}

	@SuppressWarnings("deprecation")
	public String updateProductData(int pid, String amount, String pname) {
		Session session = sessionFactory.getCurrentSession();
		int response = session.getNamedQuery("Product.update").setInteger("pid", pid).setString("pname", pname)
				.setString("amount", amount).executeUpdate();
		return response == 1 ? "success" : "failure";

	}

	@SuppressWarnings("deprecation")
	public String deleteProductData(int pid) {
		Session session = sessionFactory.getCurrentSession();
		int response = session.getNamedQuery("Product.delete").setInteger("pid", pid).executeUpdate();
		return response == 1 ? "success" : "failure";
	}

}