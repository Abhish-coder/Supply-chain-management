package com.legato.scm.controller;

public class RegistrationController {
	

}
