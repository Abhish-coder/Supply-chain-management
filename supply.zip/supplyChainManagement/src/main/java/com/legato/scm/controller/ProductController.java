package com.legato.scm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.legato.scm.pojo.Product;
import com.legato.scm.pojo.Products;
import com.legato.scm.service.SCMProductService;

@RequestMapping("/Product")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class ProductController {

	@Autowired
	SCMProductService scmProductService;

	@RequestMapping(value = "viewProducts", method = RequestMethod.GET)
	public Products viewProductsData() {
		Products products = scmProductService.getProductData();
		return products;
	}

	@RequestMapping(value = "saveProductData", method = RequestMethod.POST)
	public String saveEmployeesData(@RequestBody Products Products) {
		String message = null;
		for (Product product : Products.getProducts())
			message = scmProductService.saveProductData(product);
		return message;
	}

	@RequestMapping(value = "deleteProductData/{pid}", method = RequestMethod.DELETE)
	public String deleteEmployeesData(@PathVariable("pid") String pid) {
		String message = scmProductService.deleteProductData(pid);
		return message;
	}

	@RequestMapping(value = "updateProductData", method = RequestMethod.PUT)
	public String updateProductData(@RequestBody Products products) {
		String message = null;
		for (Product product : products.getProducts())
			message = scmProductService.updateProductData(String.valueOf(product.getPid()), product.getAmount(),
					product.getPname());
		return message;
	}

}