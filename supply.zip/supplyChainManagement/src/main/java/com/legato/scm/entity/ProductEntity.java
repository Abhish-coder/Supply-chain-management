package com.legato.scm.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SCM_Product")
@NamedQueries({ @NamedQuery(name = "Product.view", query = "from ProductEntity"),
		@NamedQuery(name = "Product.delete", query = "delete from ProductEntity p where p.pid=:pid"),
		@NamedQuery(name = "Product.update", query = "update ProductEntity p set p.pname = :name, p.amount = :amount where p.pid=:pid") })

public class ProductEntity {

	@Id
	@SequenceGenerator(name = "ProductEntitySeq", sequenceName = "SCM_USERENTITY_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ProductEntitySeq")
	@Column(name = "PID")
	private int pid;

	@Column(name = "AMOUNT")
	private String amount;

	@Column(name = "MANUFACTUREID")
	private int manufactureId;

	@Column(name = "PNAME")
	private String pname;

	@Column(name = "CREATEDAT")
	private Date createdAt;

	@Column(name = "QUANTITYAVAILABLE")
	private int quantityAvailable;

	@Column(name = "DESIGN")
	private String design;

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public int getManufactureId() {
		return manufactureId;
	}

	public void setManufactureId(int manufactureId) {
		this.manufactureId = manufactureId;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public int getQuantityAvailable() {
		return quantityAvailable;
	}

	public void setQuantityAvailable(int quantityAvailable) {
		this.quantityAvailable = quantityAvailable;
	}

	public String getDesign() {
		return design;
	}

	public void setDesign(String design) {
		this.design = design;
	}

}